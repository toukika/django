# -*- coding: utf-8 -*-
import scrapy
import re
import lxml.html
import csv,os,json
import time
import requests
from lxml import html 
from time import sleep
from .. import items
from selenium import webdriver

class AmazoncrawlSpider(scrapy.Spider):
    name = 'amazonCrawl'
    allowed_domains = ['amazon.co.jp']
    start_urls = ['http://amazon.co.jp/']


    def start_requests(self):
    	#CSVからkeywordsを取得してurlを生成します。
    	with open(os.path.join(os.path.dirname(__file__),"../resources/keywords_jp.csv"),'r',encoding="utf-8_sig") as search_keywords:
    		print(search_keywords)
    		for keyword in csv.DictReader(search_keywords):
    			search_text=keyword["keyword"]
    			url = "https://www.amazon.co.jp/s?k={0}".format(search_text)
    			yield scrapy.Request(url,callback=self.parse, meta = {"search_text": search_text})


    def parse(self, response):
    	search_keyword=response.meta["search_text"]
    	driver = webdriver.Chrome()
    	#カテゴリーはCDの場合:urlを取得する
    	url = response.xpath('//*[@id="p_n_srvg_2374648051/81873051"]/span/a/@href').get()
    	cdUrl = response.urljoin(url)
    	driver.get(cdUrl)
    	aclass = driver.find_elements_by_xpath('//*[@id="search"]/div[1]/div[2]/div/span[3]/div[1]/div/div/div/div/div[2]/div[4]/div/div[1]/div[1]/a')
    	for a in aclass:
    		hreflist = []
    		href = a.get_attribute("href")
    		hreflist.append(href)
    		for asin in hreflist:
    			searchASIN = re.search(r'B[A-Z0-9]{9}',href)
    			AsinList = []
    			AsinList.append(searchASIN.group(0))
    			extracted_data=[]
    			for i in AsinList:
    				aurl = "https://www.amazon.co.jp/dp/"+i
    				print("processing"+aurl)
    				nameList=[]
    				headers = {'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/76.0.3809.132 Safari/537.36'}
    				response1 = requests.get(aurl,headers=headers)
    				page=lxml.html.formstring(response.content)
    				time.sleep(2)
    				#「この商品を買った人はこんな商品も買っています」が存在するかどうかを判断する
    				if bool(page.xpath('//*[@id="desktop-dp-sims_purchase-similarities-sims-feature"]/div'))==True:
    					findDivTagString = page.xpath('//*[@id="desktop-dp-sims_purchase-similarities-sims-feature"]/div/@data-a-carousel-options')[0]
    					jsonValue = json.loads(findDivTagString)
    					itemList = joinValue["ajax"]["id_list"]
    					for item in itemList:
    						itemASIN = re.search(r'[A-Z0-9]{10}',item)
    						relist = []
    						relist.append(itemASIN.group(0))
    						for re in relist:
    							nurl = "https://www.amazon.co.jp/dp/"+re
    							print("nameUrl"+nurl)
    							response2 = requests.get(nurl,headers=headers)
    							page1=lxml.html.formstring(response2.content)
    							time.sleep(2)
    							findName= ''
    							#名前が存在するかどうかを判断する
    							if bool(page.xpath('//*[@id="bylineInfo"]/span[1]/a'))== True:
    								findName = page1.xpath('//*[@id="bylineInfo"]/span[1]/a')[0].text
    							else:
    								findName = ''
    							nameList.append(findName)
    				
    				sleep(2)
    				list_set = set(nameList)
    				for name in list_set:
    					num = nameList.count(name)
    					cd = "CD"
    					if name is not None:
    						item = items.ScrapyappItem()
    						item['name']=name
    						item['number']=num
    						item['category']=cd
    						yield item

    	next_page = response.xpath('//*[@id="search"]/div[1]/div[2]/div/span[7]/div/div/div/ul/li/a')
    	if next_page is not None:
    		next_page = response.urljoin(next_page)
    		yield scrapy.Request(next_page,callback=self.parse)										
        #pass

		#カテゴリーはDVDの場合:urlを取得する
    	url = response.xpath('//*[@id="p_n_srvg_2374648051/81873051"]/span/a/@href').get()
    	cdUrl = response.urljoin(url)
    	driver.get(cdUrl)
    	aclass = driver.find_elements_by_xpath('//*[@id="search"]/div[1]/div[2]/div/span[3]/div[1]/div/div/div/div/div[2]/div[4]/div/div[1]/div[1]/a')
    	for a in aclass:
    		hreflist = []
    		href = a.get_attribute("href")
    		hreflist.append(href)
    		for asin in hreflist:
    			searchASIN = re.search(r'B[A-Z0-9]{9}',href)
    			AsinList = []
    			AsinList.append(searchASIN.group(0))
    			extracted_data=[]
    			for i in AsinList:
    				aurl = "https://www.amazon.co.jp/dp/"+i
    				print("processing"+aurl)
    				nameList=[]
    				headers = {'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/76.0.3809.132 Safari/537.36'}
    				response1 = requests.get(aurl,headers=headers)
    				page=lxml.html.formstring(response.content)
    				time.sleep(2)
    				#「この商品を買った人はこんな商品も買っています」が存在するかどうかを判断する
    				if bool(page.xpath('//*[@id="desktop-dp-sims_purchase-similarities-sims-feature"]/div'))==True:
    					findDivTagString = page.xpath('//*[@id="desktop-dp-sims_purchase-similarities-sims-feature"]/div/@data-a-carousel-options')[0]
    					jsonValue = json.loads(findDivTagString)
    					itemList = joinValue["ajax"]["id_list"]
    					for item in itemList:
    						itemASIN = re.search(r'[A-Z0-9]{10}',item)
    						relist = []
    						relist.append(itemASIN.group(0))
    						for re in relist:
    							nurl = "https://www.amazon.co.jp/dp/"+re
    							print("nameUrl"+nurl)
    							response2 = requests.get(nurl,headers=headers)
    							page1=lxml.html.formstring(response2.content)
    							time.sleep(2)
    							findName= ''
    							if bool(page.xpath('//*[@id="bylineInfo"]/span[1]/a'))== True:
    								findName = page1.xpath('//*[@id="bylineInfo"]/span[1]/a')[0].text
    							else:
    								findName = ''
    							nameList.append(findName)
    				
    				sleep(2)
    				list_set = set(nameList)
    				for name in list_set:
    					num = nameList.count(name)
    					cd = "DVD"
    					if name is not None:
    						#DBに保存する
    						item = items.ScrapyappItem()
    						item['name']=name
    						item['number']=num
    						item['category']=cd
    						yield item


    	#複数ページがあれば：					
    	next_page = response.xpath('//*[@id="search"]/div[1]/div[2]/div/span[7]/div/div/div/ul/li/a')
    	if next_page is not None:
    		next_page = response.urljoin(next_page)
    		yield scrapy.Request(next_page,callback=self.parse)					

    	
    	#カテゴリーはDVDの場合:urlを取得する
    	url = response.xpath('//*[@id="p_n_srvg_2374648051/81873051"]/span/a/@href').get()
    	cdUrl = response.urljoin(url)
    	driver.get(cdUrl)
    	aclass = driver.find_elements_by_xpath('//*[@id="search"]/div[1]/div[2]/div/span[3]/div[1]/div/div/div/div/div[2]/div[4]/div/div[1]/div[1]/a')
    	for a in aclass:
    		hreflist = []
    		href = a.get_attribute("href")
    		hreflist.append(href)
    		for asin in hreflist:
    			searchASIN = re.search(r'B[A-Z0-9]{9}',href)
    			AsinList = []
    			AsinList.append(searchASIN.group(0))
    			extracted_data=[]
    			for i in AsinList:
    				aurl = "https://www.amazon.co.jp/dp/"+i
    				print("processing"+aurl)
    				nameList=[]
    				headers = {'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/76.0.3809.132 Safari/537.36'}
    				response1 = requests.get(aurl,headers=headers)
    				page=lxml.html.formstring(response.content)
    				time.sleep(2)
    				#「この商品を買った人はこんな商品も買っています」が存在するかどうかを判断する
    				if bool(page.xpath('//*[@id="desktop-dp-sims_purchase-similarities-sims-feature"]/div'))==True:
    					findDivTagString = page.xpath('//*[@id="desktop-dp-sims_purchase-similarities-sims-feature"]/div/@data-a-carousel-options')[0]
    					jsonValue = json.loads(findDivTagString)
    					itemList = joinValue["ajax"]["id_list"]
    					for item in itemList:
    						itemASIN = re.search(r'[A-Z0-9]{10}',item)
    						relist = []
    						relist.append(itemASIN.group(0))
    						for re in relist:
    							nurl = "https://www.amazon.co.jp/dp/"+re
    							print("nameUrl"+nurl)
    							response2 = requests.get(nurl,headers=headers)
    							page1=lxml.html.formstring(response2.content)
    							time.sleep(2)
    							findName= ''
    							if bool(page.xpath('//*[@id="bylineInfo"]/span[1]/a'))== True:
    								findName = page1.xpath('//*[@id="bylineInfo"]/span[1]/a')[0].text
    							else:
    								findName = ''
    							nameList.append(findName)
    				
    				list_set = set(nameList)
    				for name in list_set:
    					num = nameList.count(name)
    					cd = "ブルーレイ"
    					if name is not None:
    						#DBに保存する
    						item = items.ScrapyappItem()
    						item['name']=name
    						item['number']=num
    						item['category']=cd
    						yield item
    						

    	#複数ページがあれば：					
    	next_page = response.xpath('//*[@id="search"]/div[1]/div[2]/div/span[7]/div/div/div/ul/li/a')
    	if next_page is not None:
    		next_page = response.urljoin(next_page)
    		yield scrapy.Request(next_page,callback=self.parse)		