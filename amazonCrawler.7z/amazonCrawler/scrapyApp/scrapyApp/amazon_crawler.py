# -*- coding: utf-8 -*-
import scrapy
import csv,os,json
import requests
import re
import time
import lxml.html
from time import sleep
from bs4 import BeautifulSoup
from lxml import html 

from .. import items

class NamedetailscrapySpider(scrapy.Spider):
    name = 'amazon_crawler'
    allowed_domains = ['amazon.co.jp']
    start_urls = ['http://amazon.co.jp/']

    def start_requests(self):
    	"""CSVからkeywordsを取得してurlを生成します"""
    	with open(os.path.join(os.path.dirname(__file__), "../resources/keywords_jp.csv"),'r',encoding="utf-8_sig") as search_keywords:
    		print(search_keywords)
    		for keyword in csv.DictReader(search_keywords):
    			search_text=keyword["keyword"]
    			url="https://www.amazon.co.jp/s?k={0}".format(search_text)
    			yield scrapy.Request(url, callback = self.parse, meta = {"search_text": search_text})


    def namesParser(self,searchUrl,nameList):

	    headers = {'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/76.0.3809.132 Safari/537.36'}
	    response = requests.get(searchUrl,headers=headers)
	    page = lxml.html.fromstring(response.content)
	    time.sleep(5)
	    findName = ''
        #名前が存在するかどうかを判断する
	    if bool(page.xpath('//*[@id="bylineInfo"]/span[1]/a'))== True:
	        findName = page.xpath('//*[@id="bylineInfo"]/span[1]/a')[0].text
	    else:
	        findName = ''
	   
	    nameList.append(findName)


    def divParser(self,url,nameList):

	    headers = {'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/76.0.3809.132 Safari/537.36'}
	    response = requests.get(url,headers=headers)
	    page = lxml.html.fromstring(response.content)
	    time.sleep(5)
	    #「この商品を買った人はこんな商品も買っています」が存在するかどうかを判断する
	    if bool(page.xpath('//*[@id="desktop-dp-sims_purchase-similarities-sims-feature"]/div')) == True:
	        findDivTagString = page.xpath('//*[@id="desktop-dp-sims_purchase-similarities-sims-feature"]/div/@data-a-carousel-options')[0] 
	        jsonValue = json.loads(findDivTagString)
	        itemList = jsonValue["ajax"]["id_list"]
	        for item in itemList:
                itemASIN = re.search(r'[A-Z0-9]{10}',item)
                AsinList = []
                AsinList.append(itemASIN.group(0))
                extracted_data = []
                for i in AsinList:
                    url = "https://www.amazon.co.jp/dp/"+i
                    print ("nameUrl:"+url)
                    #名前を取得する
                    extracted_data.append(self.namesParser(url,nameList))
                    time.sleep(5)


    def parse(self, response):
    	search_keyword=response.meta["search_text"]
        #カテゴリー<a>のxpathを取得します。
    	allAClass=response.xpath('//*[@id="search"]/div[1]/div[2]/div/span[3]/div[1]/div/div/div/div/div[2]/div[4]/div/div[1]/div[1]/a')
    	for link in allAClass :
        	links = []
        	hrefString = link.xpath('text()').get().strip()
            #カテゴリーはCDの場合
        	if "CD" in hrefString:
        		href = link.xpath('@href').get()
        		links.append(href)
        		for delink in links:
        			searchASIN = re.search(r'B[A-Z0-9]{9}', delink)
        			AsinList = []
        			AsinList.append(searchASIN.group(0))
        			extracted_data = []
        			for i in AsinList:
        				url = "https://www.amazon.co.jp/dp/"+i
        				print ("Processing:"+url)
        				nameList = []
        				extracted_data.append(self.divParser(url,nameList))
        				sleep(5)
        				list_set = set(nameList)
        				for name in list_set:
        					num = nameList.count(name)
        					cd = "CD"
        					#print("the %s has found %d" %(name,nameList.count(name)))
        					#print(name)
                            if name is not None:
                                #DBに保存する
            					item = items.ScrapyappItem()
            					item['name']=name
            					item['number']=num
            					item['category']=cd
            					yield item

                #カテゴリーはDVDの場合            
                if "DVD" in hrefString:
                    href = link.xpath('@href').get()
                    links.append(href)
                    for delink in links:
                        searchASIN = re.search(r'B[A-Z0-9]{9}', delink)
                        AsinList = []
                        AsinList.append(searchASIN.group(0))
                        extracted_data = []
                        for i in AsinList:
                            url = "https://www.amazon.co.jp/dp/"+i
                            print ("Processing:"+url)
                            nameList = []
                            extracted_data.append(self.divParser(url,nameList))
                            sleep(5)
                            list_set = set(nameList)
                            for name in list_set:
                                num = nameList.count(name)
                                cd = "DVD"
                                #print("the %s has found %d" %(name,nameList.count(name)))
                                #print(name)
                                if name is not None:
                                    #DBに保存する
                                    item = items.ScrapyappItem()
                                    item['name']=name
                                    item['number']=num
                                    item['category']=cd
                                    yield item

                
                #カテゴリーはDVDの場合            
                if "Blu-ray" in hrefString:
                    href = link.xpath('@href').get()
                    links.append(href)
                    for delink in links:
                        searchASIN = re.search(r'B[A-Z0-9]{9}', delink)
                        AsinList = []
                        AsinList.append(searchASIN.group(0))
                        extracted_data = []
                        for i in AsinList:
                            url = "https://www.amazon.co.jp/dp/"+i
                            print ("Processing:"+url)
                            nameList = []
                            extracted_data.append(self.divParser(url,nameList))
                            sleep(5)
                            list_set = set(nameList)
                            for name in list_set:
                                num = nameList.count(name)
                                cd = "ブルーレイ"
                                #print("the %s has found %d" %(name,nameList.count(name)))
                                #print(name)
                                if name is not None:
                                    #DBに保存する
                                    item = items.ScrapyappItem()
                                    item['name']=name
                                    item['number']=num
                                    item['category']=cd
                                    yield item


        #複数ページがあれば：                                            
        next_page = response.xpath('//*[@id="search"]/div[1]/div[2]/div/span[7]/div/div/div/ul/li[7]/a/@href')
        if next_page is not None:
        	next_page = response.urljoin(next_page)
        	yield scrapy.Request(next_page, callback=self.parse)
