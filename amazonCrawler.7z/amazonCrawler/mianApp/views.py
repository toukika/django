from django.core.paginator import Paginator
from django.http import HttpResponse
from django.shortcuts import render
from django.http import JsonResponse

#scrapyd = ScrapydAPI('http://localhost:6800')
# Create your views here.
from mianApp.models import NameItem

def index(request):
	object_list = NameItem.objects.order_by('-name')
	context = {'object_list': object_list}
	return render(request,'index.html',context)
    #return render(request, 'index.html', context)

def detail(request, num=1):
    list = NameItem.objects.order_by('-name')
    paginator = Paginator(list, 10)

    page = paginator.page(num)

    return render(request, 'index.html', {'spotList': page, 'key': 'detail'})

