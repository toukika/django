from django.contrib import admin
from mianApp.models import NameItem
# Register your models here.
@admin.register(NameItem)
class SpotAdmin(admin.ModelAdmin):
    # 设置页面列的名称
    list_display = ['pk', 'name', 'number', 'category']
    list_per_page = 10

    ordering = ('pk',)

    search_fields = ['name']

    # 执行动作的位置
    actions_on_bottom = True
    actions_on_top = False