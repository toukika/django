from django.db import models

# Create your models here.
class NameItem(models.Model):
	name = models.CharField(max_length = 50,default='')
	number = models.IntegerField()
	category = models.CharField(max_length = 30,default='')

#class Meta():
	#db_table='nameitem'